Turquoise_0639_Notched
Style: notched
Theme #0639 of 1000
Roundedness: 0.30
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
