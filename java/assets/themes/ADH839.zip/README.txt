ADH0839 / 839 of 1000
Geometry: inner-frame
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
