ADH0190 / 190 of 1000
Geometry: notched
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
