ADH0804 / 804 of 1000
Geometry: diamond
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
