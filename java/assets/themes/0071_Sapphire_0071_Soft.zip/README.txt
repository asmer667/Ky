Sapphire_0071_Soft
Style: soft
Theme #0071 of 1000
Roundedness: 0.50
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
