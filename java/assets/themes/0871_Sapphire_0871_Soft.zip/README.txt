Sapphire_0871_Soft
Style: soft
Theme #0871 of 1000
Roundedness: 0.50
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
