Gold_0733_Sharp
Style: sharp
Theme #0733 of 1000
Roundedness: 0.18
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
