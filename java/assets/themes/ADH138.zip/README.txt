ADH0138 / 138 of 1000
Geometry: hex-rounded
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
