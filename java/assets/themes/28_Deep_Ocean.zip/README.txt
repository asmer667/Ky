28_Deep_Ocean
Style: rounded
Roundedness: 0.95
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
