Ocean_0837_Neon
Style: neon
Theme #0837 of 1000
Roundedness: 0.58
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
