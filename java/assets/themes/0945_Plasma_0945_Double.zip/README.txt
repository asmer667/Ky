Plasma_0945_Double
Style: double
Theme #0945 of 1000
Roundedness: 0.62
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
