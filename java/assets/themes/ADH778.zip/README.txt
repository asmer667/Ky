ADH0778 / 778 of 1000
Geometry: hex-rounded
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
