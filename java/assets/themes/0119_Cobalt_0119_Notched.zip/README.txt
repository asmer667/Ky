Cobalt_0119_Notched
Style: notched
Theme #0119 of 1000
Roundedness: 0.30
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
