Mango_0373_Sharp
Style: sharp
Theme #0373 of 1000
Roundedness: 0.18
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
