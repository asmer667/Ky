Peach_0271_Soft
Style: soft
Theme #0271 of 1000
Roundedness: 0.50
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
