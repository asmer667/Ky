01_Neon_Cyan
Style: neon
Roundedness: 0.82
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
