Toxic
Primary: #8cff00
Key: #1b3004
Background: #071000
Roundedness: 0.87
