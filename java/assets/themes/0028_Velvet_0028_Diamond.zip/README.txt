Velvet_0028_Diamond
Style: diamond
Theme #0028 of 1000
Roundedness: 0.42
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
