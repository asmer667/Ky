Sunset_0162_Pill
Style: pill
Theme #0162 of 1000
Roundedness: 0.85
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
