17_Aurora
Style: glow
Roundedness: 0.9
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
