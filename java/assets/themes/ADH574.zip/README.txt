ADH0574 / 574 of 1000
Geometry: stepped
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
