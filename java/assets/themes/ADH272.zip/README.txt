ADH0272 / 272 of 1000
Geometry: corner-brackets
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
