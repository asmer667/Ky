ADH0087 / 87 of 1000
Geometry: ticket
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
