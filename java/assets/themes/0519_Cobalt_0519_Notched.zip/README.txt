Cobalt_0519_Notched
Style: notched
Theme #0519 of 1000
Roundedness: 0.30
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
