Aurora_0810_Arc
Style: arc
Theme #0810 of 1000
Roundedness: 0.68
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
