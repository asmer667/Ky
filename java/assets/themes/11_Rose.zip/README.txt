Rose
Primary: #ff6fae
Key: #3b1226
Background: #190711
Roundedness: 0.88
