Indigo_0627_Neon
Style: neon
Theme #0627 of 1000
Roundedness: 0.58
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
