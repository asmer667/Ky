Obsidian_0693_Sharp
Style: sharp
Theme #0693 of 1000
Roundedness: 0.18
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
