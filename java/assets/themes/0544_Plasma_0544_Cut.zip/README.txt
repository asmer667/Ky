Plasma_0544_Cut
Style: cut
Theme #0544 of 1000
Roundedness: 0.35
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
