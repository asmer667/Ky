Amethyst_0861_Soft
Style: soft
Theme #0861 of 1000
Roundedness: 0.50
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
