Plasma_0148_Diamond
Style: diamond
Theme #0148 of 1000
Roundedness: 0.42
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
