10_Titanium
Style: metal
Roundedness: 0.7
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
