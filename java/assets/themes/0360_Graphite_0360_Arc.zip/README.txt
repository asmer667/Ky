Graphite_0360_Arc
Style: arc
Theme #0360 of 1000
Roundedness: 0.68
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
