Sky_0761_Soft
Style: soft
Theme #0761 of 1000
Roundedness: 0.50
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
