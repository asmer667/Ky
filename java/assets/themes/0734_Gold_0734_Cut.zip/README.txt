Gold_0734_Cut
Style: cut
Theme #0734 of 1000
Roundedness: 0.35
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
