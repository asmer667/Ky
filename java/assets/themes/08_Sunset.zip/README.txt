Sunset
Primary: #ff8a3d
Key: #3a1c0b
Background: #1b0c05
Roundedness: 0.82
