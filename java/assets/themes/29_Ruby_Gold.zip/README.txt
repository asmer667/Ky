29_Ruby_Gold
Style: gold
Roundedness: 0.74
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
