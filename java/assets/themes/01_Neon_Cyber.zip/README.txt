Neon Cyber
Primary: #00e5ff
Key: #102a3a
Background: #07121b
Roundedness: 0.92
