12_Black_Blue
Style: edge
Roundedness: 0.74
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
