Aurora_0801_Soft
Style: soft
Theme #0801 of 1000
Roundedness: 0.50
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
