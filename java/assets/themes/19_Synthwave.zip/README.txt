19_Synthwave
Style: neon
Roundedness: 0.8
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
