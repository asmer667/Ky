Amethyst_0070_Arc
Style: arc
Theme #0070 of 1000
Roundedness: 0.68
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
