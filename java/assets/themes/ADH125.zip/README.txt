ADH0125 / 125 of 1000
Geometry: cut-corners
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
