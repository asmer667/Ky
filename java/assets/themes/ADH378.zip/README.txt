ADH0378 / 378 of 1000
Geometry: hex-rounded
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
