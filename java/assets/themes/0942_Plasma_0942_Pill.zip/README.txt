Plasma_0942_Pill
Style: pill
Theme #0942 of 1000
Roundedness: 0.85
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
