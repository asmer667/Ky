ADH0423 / 423 of 1000
Geometry: hexagon
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
