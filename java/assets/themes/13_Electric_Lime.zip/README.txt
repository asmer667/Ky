Electric Lime
Primary: #b8ff25
Key: #24320a
Background: #0b1203
Roundedness: 0.84
