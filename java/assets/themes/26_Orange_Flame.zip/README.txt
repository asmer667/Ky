Orange Flame
Primary: #ff9d35
Key: #3c1b08
Background: #180a03
Roundedness: 0.92
