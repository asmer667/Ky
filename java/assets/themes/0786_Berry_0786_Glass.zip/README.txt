Berry_0786_Glass
Style: glass
Theme #0786 of 1000
Roundedness: 0.72
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
