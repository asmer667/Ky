Mango_0377_Neon
Style: neon
Theme #0377 of 1000
Roundedness: 0.58
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
