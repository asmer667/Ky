Pine_0791_Soft
Style: soft
Theme #0791 of 1000
Roundedness: 0.50
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
