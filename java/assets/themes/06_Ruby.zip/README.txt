Ruby
Primary: #ff4d6d
Key: #3b111b
Background: #19070c
Roundedness: 0.86
