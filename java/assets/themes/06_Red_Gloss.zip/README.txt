06_Red_Gloss
Style: gloss
Roundedness: 0.76
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
