Plasma_0943_Sharp
Style: sharp
Theme #0943 of 1000
Roundedness: 0.18
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
