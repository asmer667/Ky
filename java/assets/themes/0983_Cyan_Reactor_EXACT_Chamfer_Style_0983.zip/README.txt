Cyan Reactor EXACT Chamfer Style 0983
Theme #0983 / 1000
Geometry: chamfer
Palette: Cyan Reactor
Variant: EXACT
Text weight: 600 (high readability)
Note: the supplied FUTO format exposes normal/pressed/functional/action border selectors; special keys such as X/search/emoji inherit the corresponding FUTO functional/action class rather than using unsupported invented selector names.
