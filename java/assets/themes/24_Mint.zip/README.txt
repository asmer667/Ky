Mint
Primary: #5fffd0
Key: #123329
Background: #04120e
Roundedness: 0.83
