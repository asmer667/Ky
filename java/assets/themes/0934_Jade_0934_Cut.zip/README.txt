Jade_0934_Cut
Style: cut
Theme #0934 of 1000
Roundedness: 0.35
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
