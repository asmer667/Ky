26_Laser_Lime
Style: neon
Roundedness: 0.85
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
