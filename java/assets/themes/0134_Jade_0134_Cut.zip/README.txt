Jade_0134_Cut
Style: cut
Theme #0134 of 1000
Roundedness: 0.35
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
