Lavender_0103_Sharp
Style: sharp
Theme #0103 of 1000
Roundedness: 0.18
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
