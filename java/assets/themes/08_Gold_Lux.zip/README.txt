08_Gold_Lux
Style: gold
Roundedness: 0.72
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
