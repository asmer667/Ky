Coffee
Primary: #d9a066
Key: #322016
Background: #120b07
Roundedness: 0.8
