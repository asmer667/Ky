Sunset_0167_Neon
Style: neon
Theme #0167 of 1000
Roundedness: 0.58
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
