24_Amber_Dark
Style: rounded
Roundedness: 0.91
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
