Arctic
Primary: #52d9ff
Key: #15323c
Background: #061116
Roundedness: 0.76
