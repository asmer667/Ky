ADH0096 / 96 of 1000
Geometry: angled-left
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
