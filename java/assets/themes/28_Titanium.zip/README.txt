Titanium
Primary: #b9c1cb
Key: #252b33
Background: #0b0e12
Roundedness: 0.74
