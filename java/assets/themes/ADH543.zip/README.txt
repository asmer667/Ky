ADH0543 / 543 of 1000
Geometry: hexagon
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
