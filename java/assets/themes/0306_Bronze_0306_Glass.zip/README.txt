Bronze_0306_Glass
Style: glass
Theme #0306 of 1000
Roundedness: 0.72
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
