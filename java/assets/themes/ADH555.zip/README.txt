ADH0555 / 555 of 1000
Geometry: soft-square
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
