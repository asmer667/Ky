ADH0400 / 400 of 1000
Geometry: bevel
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
