11_Black_Red
Style: edge
Roundedness: 0.72
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
