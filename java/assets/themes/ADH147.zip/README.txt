ADH0147 / 147 of 1000
Geometry: ticket
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
