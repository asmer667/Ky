ADH0384 / 384 of 1000
Geometry: diamond
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
