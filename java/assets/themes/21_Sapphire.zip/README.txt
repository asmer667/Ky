21_Sapphire
Style: glass
Roundedness: 0.79
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
