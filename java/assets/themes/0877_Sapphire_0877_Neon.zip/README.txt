Sapphire_0877_Neon
Style: neon
Theme #0877 of 1000
Roundedness: 0.58
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
