Aurora
Primary: #4fffb0
Key: #123326
Background: #061510
Roundedness: 0.96
