Berry_0783_Sharp
Style: sharp
Theme #0783 of 1000
Roundedness: 0.18
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
