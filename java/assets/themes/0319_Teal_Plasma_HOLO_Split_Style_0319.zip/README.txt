Teal Plasma HOLO Split Style 0319
Theme #0319 / 1000
Geometry: split
Palette: Teal Plasma
Variant: HOLO
Text weight: 600 (high readability)
Note: the supplied FUTO format exposes normal/pressed/functional/action border selectors; special keys such as X/search/emoji inherit the corresponding FUTO functional/action class rather than using unsupported invented selector names.
