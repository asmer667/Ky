Ocean_0440_Arc
Style: arc
Theme #0440 of 1000
Roundedness: 0.68
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
