02_Neon_Purple
Style: neon
Roundedness: 0.86
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
