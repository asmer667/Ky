Nebula_0417_Neon
Style: neon
Theme #0417 of 1000
Roundedness: 0.58
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
