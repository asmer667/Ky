Lavender_0504_Cut
Style: cut
Theme #0504 of 1000
Roundedness: 0.35
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
