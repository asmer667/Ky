Plasma_0144_Cut
Style: cut
Theme #0144 of 1000
Roundedness: 0.35
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
