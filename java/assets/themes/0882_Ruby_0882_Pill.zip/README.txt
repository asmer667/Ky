Ruby_0882_Pill
Style: pill
Theme #0882 of 1000
Roundedness: 0.85
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
