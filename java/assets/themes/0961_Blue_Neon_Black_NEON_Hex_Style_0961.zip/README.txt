Blue Neon Black NEON Hex Style 0961
Theme #0961 / 1000
Geometry: hex
Palette: Blue Neon Black
Variant: NEON
Text weight: 600 (high readability)
Note: the supplied FUTO format exposes normal/pressed/functional/action border selectors; special keys such as X/search/emoji inherit the corresponding FUTO functional/action class rather than using unsupported invented selector names.
