ADH0340 / 340 of 1000
Geometry: bevel
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
