Ocean_0039_Notched
Style: notched
Theme #0039 of 1000
Roundedness: 0.30
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
