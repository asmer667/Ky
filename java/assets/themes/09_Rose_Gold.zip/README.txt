09_Rose_Gold
Style: gold
Roundedness: 0.75
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
