25_Platinum
Style: metal
Roundedness: 0.68
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
