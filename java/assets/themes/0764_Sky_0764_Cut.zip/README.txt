Sky_0764_Cut
Style: cut
Theme #0764 of 1000
Roundedness: 0.35
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
