Frost_0179_Notched
Style: notched
Theme #0179 of 1000
Roundedness: 0.30
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
