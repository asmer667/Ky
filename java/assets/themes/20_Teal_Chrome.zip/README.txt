20_Teal_Chrome
Style: metal
Roundedness: 0.73
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
