Purple Plasma
Primary: #b66cff
Key: #2b1242
Background: #12071e
Roundedness: 1.0
