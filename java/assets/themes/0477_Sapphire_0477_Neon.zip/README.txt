Sapphire_0477_Neon
Style: neon
Theme #0477 of 1000
Roundedness: 0.58
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
