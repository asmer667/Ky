Violet
Primary: #8b7cff
Key: #20183d
Background: #0b0818
Roundedness: 0.97
