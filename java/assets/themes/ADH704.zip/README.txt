ADH0704 / 704 of 1000
Geometry: diamond
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
