03_Neon_Pink
Style: neon
Roundedness: 0.84
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
