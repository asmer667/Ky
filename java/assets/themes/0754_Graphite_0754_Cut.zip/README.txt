Graphite_0754_Cut
Style: cut
Theme #0754 of 1000
Roundedness: 0.35
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
