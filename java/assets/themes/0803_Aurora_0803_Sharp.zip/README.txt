Aurora_0803_Sharp
Style: sharp
Theme #0803 of 1000
Roundedness: 0.18
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
