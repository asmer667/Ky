Lavender_0904_Cut
Style: cut
Theme #0904 of 1000
Roundedness: 0.35
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
