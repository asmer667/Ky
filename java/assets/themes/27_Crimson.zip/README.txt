Crimson
Primary: #ff315b
Key: #3b0d18
Background: #17050a
Roundedness: 0.85
