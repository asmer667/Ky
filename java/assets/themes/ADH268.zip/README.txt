ADH0268 / 268 of 1000
Geometry: shield
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
