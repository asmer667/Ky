ADH0274 / 274 of 1000
Geometry: stepped
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
