Twilight_0552_Pill
Style: pill
Theme #0552 of 1000
Roundedness: 0.85
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
