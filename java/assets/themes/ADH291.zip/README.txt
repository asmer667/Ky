ADH0291 / 291 of 1000
Geometry: double-frame
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
