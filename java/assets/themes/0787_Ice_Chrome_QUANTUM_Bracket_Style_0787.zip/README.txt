Ice Chrome QUANTUM Bracket Style 0787
Theme #0787 / 1000
Geometry: bracket
Palette: Ice Chrome
Variant: QUANTUM
Text weight: 600 (high readability)
Note: the supplied FUTO format exposes normal/pressed/functional/action border selectors; special keys such as X/search/emoji inherit the corresponding FUTO functional/action class rather than using unsupported invented selector names.
