ADH0017 / 17 of 1000
Geometry: angled-right
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
