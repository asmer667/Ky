ADH0170 / 170 of 1000
Geometry: notched
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
