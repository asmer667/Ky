ADH0097 / 97 of 1000
Geometry: angled-right
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
