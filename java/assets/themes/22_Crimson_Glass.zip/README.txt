22_Crimson_Glass
Style: glass
Roundedness: 0.81
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
