Velvet_0423_Sharp
Style: sharp
Theme #0423 of 1000
Roundedness: 0.18
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
