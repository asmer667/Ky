Coral_0126_Glass
Style: glass
Theme #0126 of 1000
Roundedness: 0.72
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
