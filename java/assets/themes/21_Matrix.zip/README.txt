Matrix
Primary: #00ff66
Key: #0b2413
Background: #020b05
Roundedness: 0.89
