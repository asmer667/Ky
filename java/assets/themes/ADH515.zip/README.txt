ADH0515 / 515 of 1000
Geometry: soft-square
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
