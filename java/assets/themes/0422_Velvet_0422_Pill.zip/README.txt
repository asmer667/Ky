Velvet_0422_Pill
Style: pill
Theme #0422 of 1000
Roundedness: 0.85
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
