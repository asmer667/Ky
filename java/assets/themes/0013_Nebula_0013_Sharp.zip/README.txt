Nebula_0013_Sharp
Style: sharp
Theme #0013 of 1000
Roundedness: 0.18
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
