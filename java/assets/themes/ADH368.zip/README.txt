ADH0368 / 368 of 1000
Geometry: shield
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
