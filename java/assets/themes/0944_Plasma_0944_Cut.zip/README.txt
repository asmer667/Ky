Plasma_0944_Cut
Style: cut
Theme #0944 of 1000
Roundedness: 0.35
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
