15_Orange_Fire
Style: glow
Roundedness: 0.77
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
