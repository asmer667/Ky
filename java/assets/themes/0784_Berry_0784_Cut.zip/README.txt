Berry_0784_Cut
Style: cut
Theme #0784 of 1000
Roundedness: 0.35
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
