ADH0522 / 522 of 1000
Geometry: octagon
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
