ADH0236 / 236 of 1000
Geometry: angled-left
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
