Coral_0523_Sharp
Style: sharp
Theme #0523 of 1000
Roundedness: 0.18
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
