Amber Circuit CYBER Diamond Style 0306
Theme #0306 / 1000
Geometry: diamond
Palette: Amber Circuit
Variant: CYBER
Text weight: 600 (high readability)
Note: the supplied FUTO format exposes normal/pressed/functional/action border selectors; special keys such as X/search/emoji inherit the corresponding FUTO functional/action class rather than using unsupported invented selector names.
