Midnight Blue
Primary: #4da3ff
Key: #12233f
Background: #07101f
Roundedness: 0.88
