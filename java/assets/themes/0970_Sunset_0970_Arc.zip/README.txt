Sunset_0970_Arc
Style: arc
Theme #0970 of 1000
Roundedness: 0.68
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
