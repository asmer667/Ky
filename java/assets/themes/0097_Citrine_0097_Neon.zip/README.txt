Citrine_0097_Neon
Style: neon
Theme #0097 of 1000
Roundedness: 0.58
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
