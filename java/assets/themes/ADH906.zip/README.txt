ADH0906 / 906 of 1000
Geometry: trapezoid
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
