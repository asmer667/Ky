Citrine_0496_Glass
Style: glass
Theme #0496 of 1000
Roundedness: 0.72
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
