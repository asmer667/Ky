18_Cosmic
Style: glow
Roundedness: 0.88
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
