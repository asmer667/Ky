Ruby_0084_Cut
Style: cut
Theme #0084 of 1000
Roundedness: 0.35
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
