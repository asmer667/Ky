Magenta_0328_Diamond
Style: diamond
Theme #0328 of 1000
Roundedness: 0.42
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
