Ocean
Primary: #16c7ff
Key: #0a3342
Background: #03141b
Roundedness: 0.94
