Royal
Primary: #6f7dff
Key: #1b2050
Background: #080a1b
Roundedness: 0.99
