Lava
Primary: #ff542e
Key: #3a1009
Background: #160704
Roundedness: 0.91
