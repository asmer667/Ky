Ruby_0883_Sharp
Style: sharp
Theme #0883 of 1000
Roundedness: 0.18
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
