ADH0208 / 208 of 1000
Geometry: shield
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
