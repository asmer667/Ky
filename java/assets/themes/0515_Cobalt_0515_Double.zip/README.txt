Cobalt_0515_Double
Style: double
Theme #0515 of 1000
Roundedness: 0.62
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
