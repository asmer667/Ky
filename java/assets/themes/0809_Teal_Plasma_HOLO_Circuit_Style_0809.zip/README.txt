Teal Plasma HOLO Circuit Style 0809
Theme #0809 / 1000
Geometry: circuit
Palette: Teal Plasma
Variant: HOLO
Text weight: 600 (high readability)
Note: the supplied FUTO format exposes normal/pressed/functional/action border selectors; special keys such as X/search/emoji inherit the corresponding FUTO functional/action class rather than using unsupported invented selector names.
