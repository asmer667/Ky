ADH0343 / 343 of 1000
Geometry: hexagon
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
