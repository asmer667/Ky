Copper_0214_Cut
Style: cut
Theme #0214 of 1000
Roundedness: 0.35
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
