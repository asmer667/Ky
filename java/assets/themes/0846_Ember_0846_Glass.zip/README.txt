Ember_0846_Glass
Style: glass
Theme #0846 of 1000
Roundedness: 0.72
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
