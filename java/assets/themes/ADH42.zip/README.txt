ADH0042 / 42 of 1000
Geometry: octagon
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
