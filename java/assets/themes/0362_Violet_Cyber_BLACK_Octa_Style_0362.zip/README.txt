Violet Cyber BLACK Octa Style 0362
Theme #0362 / 1000
Geometry: octa
Palette: Violet Cyber
Variant: BLACK
Text weight: 600 (high readability)
Note: the supplied FUTO format exposes normal/pressed/functional/action border selectors; special keys such as X/search/emoji inherit the corresponding FUTO functional/action class rather than using unsupported invented selector names.
