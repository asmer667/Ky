16_Ice_Glow
Style: glow
Roundedness: 0.84
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
