Twilight_0960_Arc
Style: arc
Theme #0960 of 1000
Roundedness: 0.68
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
