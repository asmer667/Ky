Carbon
Primary: #d5d8dc
Key: #20252b
Background: #0b0d10
Roundedness: 0.72
