Violet Cyber BLACK Capsule_Cut Style 0532
Theme #0532 / 1000
Geometry: capsule_cut
Palette: Violet Cyber
Variant: BLACK
Text weight: 600 (high readability)
Note: the supplied FUTO format exposes normal/pressed/functional/action border selectors; special keys such as X/search/emoji inherit the corresponding FUTO functional/action class rather than using unsupported invented selector names.
