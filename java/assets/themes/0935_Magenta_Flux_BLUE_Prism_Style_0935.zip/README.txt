Magenta Flux BLUE Prism Style 0935
Theme #0935 / 1000
Geometry: prism
Palette: Magenta Flux
Variant: BLUE
Text weight: 600 (high readability)
Note: the supplied FUTO format exposes normal/pressed/functional/action border selectors; special keys such as X/search/emoji inherit the corresponding FUTO functional/action class rather than using unsupported invented selector names.
