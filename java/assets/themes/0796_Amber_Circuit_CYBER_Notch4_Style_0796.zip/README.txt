Amber Circuit CYBER Notch4 Style 0796
Theme #0796 / 1000
Geometry: notch4
Palette: Amber Circuit
Variant: CYBER
Text weight: 600 (high readability)
Note: the supplied FUTO format exposes normal/pressed/functional/action border selectors; special keys such as X/search/emoji inherit the corresponding FUTO functional/action class rather than using unsupported invented selector names.
