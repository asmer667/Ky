ADH0249 / 249 of 1000
Geometry: parallelogram
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
