Lime_0663_Sharp
Style: sharp
Theme #0663 of 1000
Roundedness: 0.18
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
