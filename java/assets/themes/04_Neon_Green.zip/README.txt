04_Neon_Green
Style: neon
Roundedness: 0.88
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
