Synthwave
Primary: #ff38e8
Key: #2a0d3d
Background: #10051a
Roundedness: 1.0
