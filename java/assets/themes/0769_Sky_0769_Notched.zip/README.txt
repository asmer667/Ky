Sky_0769_Notched
Style: notched
Theme #0769 of 1000
Roundedness: 0.30
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
