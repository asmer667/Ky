Obsidian_0296_Glass
Style: glass
Theme #0296 of 1000
Roundedness: 0.72
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
