Lime Matrix STYLE Chevron Style 0144
Theme #0144 / 1000
Geometry: chevron
Palette: Lime Matrix
Variant: STYLE
Text weight: 600 (high readability)
Note: the supplied FUTO format exposes normal/pressed/functional/action border selectors; special keys such as X/search/emoji inherit the corresponding FUTO functional/action class rather than using unsupported invented selector names.
