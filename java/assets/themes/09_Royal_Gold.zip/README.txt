Royal Gold
Primary: #ffd24a
Key: #34280a
Background: #120e03
Roundedness: 0.9
