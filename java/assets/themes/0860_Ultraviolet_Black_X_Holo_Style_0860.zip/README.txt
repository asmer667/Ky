Ultraviolet Black X Holo Style 0860
Theme #0860 / 1000
Geometry: holo
Palette: Ultraviolet Black
Variant: X
Text weight: 600 (high readability)
Note: the supplied FUTO format exposes normal/pressed/functional/action border selectors; special keys such as X/search/emoji inherit the corresponding FUTO functional/action class rather than using unsupported invented selector names.
