Forest_0183_Sharp
Style: sharp
Theme #0183 of 1000
Roundedness: 0.18
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
