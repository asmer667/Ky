Bronze_0305_Double
Style: double
Theme #0305 of 1000
Roundedness: 0.62
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
