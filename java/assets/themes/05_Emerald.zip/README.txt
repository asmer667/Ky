Emerald
Primary: #21e6a3
Key: #103326
Background: #061510
Roundedness: 0.78
