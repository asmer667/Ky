Red Quantum VECTOR Corner Style 0228
Theme #0228 / 1000
Geometry: corner
Palette: Red Quantum
Variant: VECTOR
Text weight: 600 (high readability)
Note: the supplied FUTO format exposes normal/pressed/functional/action border selectors; special keys such as X/search/emoji inherit the corresponding FUTO functional/action class rather than using unsupported invented selector names.
