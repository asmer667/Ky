ADH0453 / 453 of 1000
Geometry: capsule
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
