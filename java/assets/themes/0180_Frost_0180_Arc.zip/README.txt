Frost_0180_Arc
Style: arc
Theme #0180 of 1000
Roundedness: 0.68
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
