Bronze_0304_Cut
Style: cut
Theme #0304 of 1000
Roundedness: 0.35
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
