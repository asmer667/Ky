Ice
Primary: #8ee8ff
Key: #18303a
Background: #071219
Roundedness: 1.0
