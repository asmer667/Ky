Red Quantum VECTOR Techplate Style 0238
Theme #0238 / 1000
Geometry: techplate
Palette: Red Quantum
Variant: VECTOR
Text weight: 600 (high readability)
Note: the supplied FUTO format exposes normal/pressed/functional/action border selectors; special keys such as X/search/emoji inherit the corresponding FUTO functional/action class rather than using unsupported invented selector names.
