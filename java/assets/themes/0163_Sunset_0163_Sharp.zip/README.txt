Sunset_0163_Sharp
Style: sharp
Theme #0163 of 1000
Roundedness: 0.18
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
