Deep Teal
Primary: #00d8c8
Key: #0b302e
Background: #031211
Roundedness: 0.9
