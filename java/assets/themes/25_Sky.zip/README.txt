Sky
Primary: #4ca9ff
Key: #132e4a
Background: #06111d
Roundedness: 0.79
