14_Violet_Black
Style: edge
Roundedness: 0.83
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
