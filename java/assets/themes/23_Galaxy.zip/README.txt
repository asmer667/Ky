Galaxy
Primary: #9d7bff
Key: #1b1238
Background: #070513
Roundedness: 0.95
