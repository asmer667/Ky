Citrine_0899_Notched
Style: notched
Theme #0899 of 1000
Roundedness: 0.30
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
