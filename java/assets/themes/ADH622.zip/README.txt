ADH0622 / 622 of 1000
Geometry: octagon
Unique palette generated for this theme.
FUTO selectors used: normal, pressed, functional, action.
