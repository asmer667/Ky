Peach_0273_Sharp
Style: sharp
Theme #0273 of 1000
Roundedness: 0.18
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
