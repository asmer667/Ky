Sakura
Primary: #ff79bd
Key: #35152a
Background: #180912
Roundedness: 0.93
