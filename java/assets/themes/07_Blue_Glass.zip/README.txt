07_Blue_Glass
Style: glass
Roundedness: 0.78
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
