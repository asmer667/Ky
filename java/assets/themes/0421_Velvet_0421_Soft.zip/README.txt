Velvet_0421_Soft
Style: soft
Theme #0421 of 1000
Roundedness: 0.50
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
