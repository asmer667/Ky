Coral_0924_Cut
Style: cut
Theme #0924 of 1000
Roundedness: 0.35
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
