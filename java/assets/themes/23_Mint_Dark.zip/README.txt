23_Mint_Dark
Style: rounded
Roundedness: 0.93
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
