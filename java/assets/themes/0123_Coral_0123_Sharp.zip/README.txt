Coral_0123_Sharp
Style: sharp
Theme #0123 of 1000
Roundedness: 0.18
Includes 9-slice PNG border assets for normal/pressed/functional/action keys.
